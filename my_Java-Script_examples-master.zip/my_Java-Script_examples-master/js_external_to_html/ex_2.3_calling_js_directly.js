function multiply (a,b)
 var c = a * b ;
console.log(c);
document.write(c);

multiply(3,6);

