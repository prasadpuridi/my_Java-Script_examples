 function sayHello(name, age)
         {
            document.write (name + " is " + age + " years old.");
         }
 